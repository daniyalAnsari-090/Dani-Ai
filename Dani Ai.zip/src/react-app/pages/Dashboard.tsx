import { useNavigate } from "react-router";
import { useAuth } from "@/react-app/context/AuthContext";
import { Button } from "@/react-app/components/ui/button";
import { ArrowLeft, Trophy, Target, Percent, Hash, Calendar, TrendingUp } from "lucide-react";

export default function Dashboard() {
  const navigate = useNavigate();
  const { user, stats } = useAuth();

  const accuracy = stats.totalQuestions > 0 
    ? Math.round((stats.correctAnswers / stats.totalQuestions) * 100) 
    : 0;

  const statCards = [
    { 
      icon: Hash, 
      label: "Total Quizzes", 
      value: stats.totalQuizzes,
      color: "from-violet-500 to-purple-500",
      description: "Quizzes completed"
    },
    { 
      icon: Trophy, 
      label: "Highest Score", 
      value: stats.highestScore,
      color: "from-amber-500 to-orange-500",
      description: "Best performance"
    },
    { 
      icon: Target, 
      label: "Last Score", 
      value: stats.lastScore,
      color: "from-emerald-500 to-cyan-500",
      description: "Most recent quiz"
    },
    { 
      icon: Percent, 
      label: "Accuracy", 
      value: `${accuracy}%`,
      color: "from-blue-500 to-indigo-500",
      description: `${stats.correctAnswers}/${stats.totalQuestions} correct`
    },
  ];

  return (
    <div className="min-h-screen bg-background p-4 sm:p-8">
      {/* Background elements */}
      <div className="fixed inset-0 pointer-events-none overflow-hidden">
        <div className="absolute top-0 right-0 w-[500px] h-[500px] bg-emerald-500/5 rounded-full blur-3xl" />
        <div className="absolute bottom-0 left-0 w-[500px] h-[500px] bg-violet-500/5 rounded-full blur-3xl" />
      </div>

      <div className="max-w-4xl mx-auto relative">
        <Button
          variant="ghost"
          onClick={() => navigate("/home")}
          className="mb-8 text-muted-foreground hover:text-foreground"
        >
          <ArrowLeft className="w-4 h-4 mr-2" />
          Back to Home
        </Button>

        {/* User Header */}
        <div className="glass rounded-2xl p-6 sm:p-8 mb-8">
          <div className="flex flex-col sm:flex-row items-center gap-6">
            <div className="w-20 h-20 rounded-full bg-gradient-to-br from-emerald-500 to-cyan-500 flex items-center justify-center text-3xl font-bold text-white">
              {user?.name?.charAt(0).toUpperCase()}
            </div>
            <div className="text-center sm:text-left">
              <h1 className="text-2xl sm:text-3xl font-bold text-foreground mb-1">{user?.name}</h1>
              <p className="text-muted-foreground">{user?.email}</p>
              <div className="flex items-center gap-2 mt-2 justify-center sm:justify-start">
                <Calendar className="w-4 h-4 text-muted-foreground" />
                <span className="text-sm text-muted-foreground">
                  Member since {new Date(user?.createdAt || "").toLocaleDateString()}
                </span>
              </div>
            </div>
          </div>
        </div>

        {/* Stats Grid */}
        <h2 className="text-xl font-semibold text-foreground mb-4 flex items-center gap-2">
          <TrendingUp className="w-5 h-5 text-emerald-400" />
          Your Statistics
        </h2>
        <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 mb-8">
          {statCards.map((stat, index) => (
            <div
              key={index}
              className="glass rounded-2xl p-6 hover:bg-white/10 transition-all duration-300 group"
            >
              <div className="flex items-start justify-between mb-4">
                <div className={`w-12 h-12 rounded-xl bg-gradient-to-br ${stat.color} flex items-center justify-center group-hover:scale-110 transition-transform`}>
                  <stat.icon className="w-6 h-6 text-white" />
                </div>
              </div>
              <div className="text-3xl font-bold text-foreground mb-1">{stat.value}</div>
              <div className="text-sm text-muted-foreground">{stat.label}</div>
              <div className="text-xs text-muted-foreground/70 mt-1">{stat.description}</div>
            </div>
          ))}
        </div>

        {/* Progress Overview */}
        {stats.totalQuizzes > 0 ? (
          <div className="glass rounded-2xl p-6 sm:p-8">
            <h3 className="text-lg font-semibold text-foreground mb-6">Progress Overview</h3>
            
            {/* Accuracy Bar */}
            <div className="mb-6">
              <div className="flex justify-between text-sm mb-2">
                <span className="text-muted-foreground">Overall Accuracy</span>
                <span className="font-medium text-foreground">{accuracy}%</span>
              </div>
              <div className="h-3 bg-secondary rounded-full overflow-hidden">
                <div 
                  className="h-full bg-gradient-to-r from-emerald-500 to-cyan-500 rounded-full transition-all duration-1000"
                  style={{ width: `${accuracy}%` }}
                />
              </div>
            </div>

            {/* Summary Stats */}
            <div className="grid grid-cols-3 gap-4 text-center">
              <div className="p-4 rounded-xl bg-white/5">
                <div className="text-2xl font-bold text-emerald-400">{stats.correctAnswers}</div>
                <div className="text-xs text-muted-foreground">Correct Answers</div>
              </div>
              <div className="p-4 rounded-xl bg-white/5">
                <div className="text-2xl font-bold text-red-400">{stats.totalQuestions - stats.correctAnswers}</div>
                <div className="text-xs text-muted-foreground">Wrong Answers</div>
              </div>
              <div className="p-4 rounded-xl bg-white/5">
                <div className="text-2xl font-bold text-violet-400">{stats.totalQuestions}</div>
                <div className="text-xs text-muted-foreground">Total Questions</div>
              </div>
            </div>
          </div>
        ) : (
          <div className="glass rounded-2xl p-8 text-center">
            <div className="w-16 h-16 rounded-full bg-white/5 flex items-center justify-center mx-auto mb-4">
              <Target className="w-8 h-8 text-muted-foreground" />
            </div>
            <h3 className="text-lg font-semibold text-foreground mb-2">No quizzes yet</h3>
            <p className="text-muted-foreground mb-6">Start your first quiz to see your statistics here</p>
            <Button
              onClick={() => navigate("/quiz")}
              className="bg-gradient-to-r from-emerald-500 to-cyan-500 hover:from-emerald-600 hover:to-cyan-600"
            >
              Start Quiz
            </Button>
          </div>
        )}
      </div>
    </div>
  );
}
