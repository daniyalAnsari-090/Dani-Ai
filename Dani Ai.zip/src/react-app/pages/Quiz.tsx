import { useState, useEffect, useCallback } from "react";
import { useNavigate } from "react-router";
import { useAuth } from "@/react-app/context/AuthContext";
import { generateQuestions, categories, Question } from "@/react-app/lib/questionEngine";
import { Button } from "@/react-app/components/ui/button";
import { Progress } from "@/react-app/components/ui/progress";
import { ArrowLeft, Clock, CheckCircle2, XCircle, AlertTriangle, Trophy, RotateCcw, Home } from "lucide-react";

type QuizState = "select" | "playing" | "result";

export default function Quiz() {
  const navigate = useNavigate();
  const { updateStats } = useAuth();
  
  const [state, setState] = useState<QuizState>("select");
  const [selectedCategory, setSelectedCategory] = useState<string | null>(null);
  const [questions, setQuestions] = useState<Question[]>([]);
  const [currentIndex, setCurrentIndex] = useState(0);
  const [score, setScore] = useState(0);
  const [correctAnswers, setCorrectAnswers] = useState(0);
  const [timeLeft, setTimeLeft] = useState(45);
  const [selectedAnswer, setSelectedAnswer] = useState<number | null>(null);
  const [showResult, setShowResult] = useState(false);
  const [skippedCount, setSkippedCount] = useState(0);

  // Timer logic
  useEffect(() => {
    if (state !== "playing" || showResult) return;

    const timer = setInterval(() => {
      setTimeLeft((prev) => {
        if (prev <= 1) {
          handleTimeout();
          return 45;
        }
        return prev - 1;
      });
    }, 1000);

    return () => clearInterval(timer);
  }, [state, currentIndex, showResult]);

  const handleTimeout = useCallback(() => {
    if (showResult) return;
    setShowResult(true);
    setTimeout(() => moveToNext(), 1500);
  }, [showResult]);

  const startQuiz = (categoryId: string) => {
    const newQuestions = generateQuestions(categoryId as "html" | "css" | "javascript" | "java" | "python", 25);
    setQuestions(newQuestions);
    setSelectedCategory(categoryId);
    setCurrentIndex(0);
    setScore(0);
    setCorrectAnswers(0);
    setSkippedCount(0);
    setTimeLeft(45);
    setSelectedAnswer(null);
    setShowResult(false);
    setState("playing");
  };

  const handleAnswer = (optionIndex: number) => {
    if (showResult || selectedAnswer !== null) return;
    
    setSelectedAnswer(optionIndex);
    setShowResult(true);

    const isCorrect = optionIndex === questions[currentIndex].correctIndex;
    if (isCorrect) {
      setScore((prev) => prev + 1);
      setCorrectAnswers((prev) => prev + 1);
    }

    setTimeout(() => moveToNext(), 1500);
  };

  const handleSkip = () => {
    if (showResult) return;
    setSkippedCount((prev) => prev + 1);
    setShowResult(true);
    setSelectedAnswer(-1); // -1 indicates skipped
    setTimeout(() => moveToNext(), 1000);
  };

  const moveToNext = () => {
    if (currentIndex >= questions.length - 1) {
      // Quiz completed
      updateStats(score + (selectedAnswer === questions[currentIndex]?.correctIndex ? 1 : 0), questions.length, correctAnswers + (selectedAnswer === questions[currentIndex]?.correctIndex ? 1 : 0));
      setState("result");
    } else {
      setCurrentIndex((prev) => prev + 1);
      setSelectedAnswer(null);
      setShowResult(false);
      setTimeLeft(45);
    }
  };

  const currentQuestion = questions[currentIndex];
  const progress = ((currentIndex + 1) / questions.length) * 100;

  // Category Selection Screen
  if (state === "select") {
    return (
      <div className="min-h-screen bg-background p-4 sm:p-8">
        <div className="max-w-4xl mx-auto">
          <Button
            variant="ghost"
            onClick={() => navigate("/home")}
            className="mb-8 text-muted-foreground hover:text-foreground"
          >
            <ArrowLeft className="w-4 h-4 mr-2" />
            Back to Home
          </Button>

          <div className="text-center mb-12">
            <h1 className="text-3xl sm:text-4xl font-bold text-foreground mb-4">Choose a Category</h1>
            <p className="text-muted-foreground">Select a programming language to start your 25-question quiz</p>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
            {categories.map((cat) => (
              <button
                key={cat.id}
                onClick={() => startQuiz(cat.id)}
                className="group glass rounded-2xl p-6 hover:bg-white/10 transition-all duration-300 hover:scale-105 text-left"
              >
                <div className={`w-16 h-16 rounded-xl bg-gradient-to-br ${cat.color} flex items-center justify-center mb-4 text-3xl group-hover:scale-110 transition-transform shadow-lg`}>
                  {cat.icon}
                </div>
                <h3 className="text-xl font-semibold text-foreground mb-2">{cat.name}</h3>
                <p className="text-sm text-muted-foreground">25 questions • 45s each</p>
              </button>
            ))}
          </div>
        </div>
      </div>
    );
  }

  // Result Screen
  if (state === "result") {
    const percentage = Math.round((score / questions.length) * 100);
    const grade = percentage >= 90 ? "A+" : percentage >= 80 ? "A" : percentage >= 70 ? "B" : percentage >= 60 ? "C" : percentage >= 50 ? "D" : "F";
    
    return (
      <div className="min-h-screen bg-background flex items-center justify-center p-4">
        <div className="glass rounded-2xl p-8 sm:p-12 max-w-md w-full text-center">
          <div className="w-24 h-24 rounded-full bg-gradient-to-br from-emerald-500 to-cyan-500 flex items-center justify-center mx-auto mb-6 glow-green">
            <Trophy className="w-12 h-12 text-white" />
          </div>

          <h1 className="text-3xl font-bold text-foreground mb-2">Quiz Complete!</h1>
          <p className="text-muted-foreground mb-8">{categories.find(c => c.id === selectedCategory)?.name} Quiz</p>

          <div className="grid grid-cols-2 gap-4 mb-8">
            <div className="glass rounded-xl p-4">
              <div className="text-3xl font-bold gradient-text">{score}/{questions.length}</div>
              <div className="text-sm text-muted-foreground">Correct</div>
            </div>
            <div className="glass rounded-xl p-4">
              <div className="text-3xl font-bold gradient-text">{percentage}%</div>
              <div className="text-sm text-muted-foreground">Accuracy</div>
            </div>
            <div className="glass rounded-xl p-4">
              <div className="text-3xl font-bold text-violet-400">{grade}</div>
              <div className="text-sm text-muted-foreground">Grade</div>
            </div>
            <div className="glass rounded-xl p-4">
              <div className="text-3xl font-bold text-amber-400">{skippedCount}</div>
              <div className="text-sm text-muted-foreground">Skipped</div>
            </div>
          </div>

          <div className="flex flex-col sm:flex-row gap-4">
            <Button
              onClick={() => startQuiz(selectedCategory!)}
              className="flex-1 h-12 bg-gradient-to-r from-emerald-500 to-cyan-500 hover:from-emerald-600 hover:to-cyan-600"
            >
              <RotateCcw className="w-4 h-4 mr-2" />
              Try Again
            </Button>
            <Button
              variant="outline"
              onClick={() => navigate("/home")}
              className="flex-1 h-12"
            >
              <Home className="w-4 h-4 mr-2" />
              Home
            </Button>
          </div>
        </div>
      </div>
    );
  }

  // Quiz Playing Screen
  return (
    <div className="min-h-screen bg-background p-4 sm:p-8">
      <div className="max-w-3xl mx-auto">
        {/* Header */}
        <div className="flex items-center justify-between mb-6">
          <div className="flex items-center gap-3">
            <span className="text-2xl">{categories.find(c => c.id === selectedCategory)?.icon}</span>
            <span className="font-semibold text-foreground">{categories.find(c => c.id === selectedCategory)?.name}</span>
          </div>
          <div className="flex items-center gap-2 text-muted-foreground">
            <span className="font-medium">{currentIndex + 1}</span>
            <span>/</span>
            <span>{questions.length}</span>
          </div>
        </div>

        {/* Progress Bar */}
        <div className="mb-6">
          <Progress value={progress} className="h-2" />
        </div>

        {/* Timer */}
        <div className="flex justify-center mb-8">
          <div className={`flex items-center gap-2 px-6 py-3 rounded-full glass ${timeLeft <= 10 ? 'bg-red-500/20 border-red-500/50' : ''}`}>
            <Clock className={`w-5 h-5 ${timeLeft <= 10 ? 'text-red-400 animate-pulse' : 'text-emerald-400'}`} />
            <span className={`text-2xl font-mono font-bold ${timeLeft <= 10 ? 'text-red-400' : 'text-foreground'}`}>
              {timeLeft}s
            </span>
          </div>
        </div>

        {/* Question */}
        <div className="glass rounded-2xl p-6 sm:p-8 mb-6">
          <h2 className="text-xl sm:text-2xl font-semibold text-foreground leading-relaxed">
            {currentQuestion?.question}
          </h2>
        </div>

        {/* Options */}
        <div className="space-y-3 mb-6">
          {currentQuestion?.options.map((option, index) => {
            const isSelected = selectedAnswer === index;
            const isCorrect = index === currentQuestion.correctIndex;
            const showCorrectWrong = showResult && (isSelected || isCorrect);

            return (
              <button
                key={index}
                onClick={() => handleAnswer(index)}
                disabled={showResult}
                className={`w-full p-4 sm:p-5 rounded-xl text-left transition-all duration-300 flex items-center gap-4 ${
                  showCorrectWrong
                    ? isCorrect
                      ? 'bg-emerald-500/20 border-2 border-emerald-500'
                      : isSelected
                        ? 'bg-red-500/20 border-2 border-red-500'
                        : 'glass'
                    : 'glass hover:bg-white/10 hover:scale-[1.02]'
                }`}
              >
                <div className={`w-10 h-10 rounded-lg flex items-center justify-center font-semibold shrink-0 ${
                  showCorrectWrong
                    ? isCorrect
                      ? 'bg-emerald-500 text-white'
                      : isSelected
                        ? 'bg-red-500 text-white'
                        : 'bg-white/10 text-foreground'
                    : 'bg-white/10 text-foreground'
                }`}>
                  {showCorrectWrong ? (
                    isCorrect ? <CheckCircle2 className="w-5 h-5" /> : isSelected ? <XCircle className="w-5 h-5" /> : String.fromCharCode(65 + index)
                  ) : (
                    String.fromCharCode(65 + index)
                  )}
                </div>
                <span className="text-foreground font-medium">{option}</span>
              </button>
            );
          })}
        </div>

        {/* Skip Button */}
        <div className="flex justify-center">
          <Button
            variant="ghost"
            onClick={handleSkip}
            disabled={showResult}
            className="text-amber-400 hover:text-amber-300 hover:bg-amber-500/10"
          >
            <AlertTriangle className="w-4 h-4 mr-2" />
            Wrong Question (Skip)
          </Button>
        </div>

        {/* Score indicator */}
        <div className="fixed bottom-4 right-4 glass rounded-full px-4 py-2 flex items-center gap-2">
          <CheckCircle2 className="w-4 h-4 text-emerald-400" />
          <span className="font-semibold text-foreground">{score}</span>
        </div>
      </div>
    </div>
  );
}
