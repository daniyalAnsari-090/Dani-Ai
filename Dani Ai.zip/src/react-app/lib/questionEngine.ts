// Dynamic Question Generator Engine
// Generates unlimited unique questions using template-based logic

export interface Question {
  id: string;
  question: string;
  options: string[];
  correctIndex: number;
  category: string;
}

type Category = "html" | "css" | "javascript" | "java" | "python";

// Data pools for each category
const questionData: Record<Category, {
  concepts: string[];
  actions: string[];
  scenarios: string[];
  keywords: string[];
  syntaxElements: string[];
  templates: ((data: typeof questionData[Category]) => { question: string; correct: string; wrong: string[] })[];
}> = {
  html: {
    concepts: ["semantic HTML", "form validation", "accessibility", "SEO optimization", "document structure", "metadata", "hyperlinks", "multimedia embedding", "tables", "lists"],
    actions: ["define", "create", "structure", "embed", "link", "validate", "organize", "display", "format", "group"],
    scenarios: ["a webpage header", "a navigation menu", "an image gallery", "a contact form", "a data table", "an article", "a footer section", "a sidebar", "a modal dialog", "a dropdown menu"],
    keywords: ["<header>", "<nav>", "<main>", "<article>", "<section>", "<aside>", "<footer>", "<figure>", "<figcaption>", "<details>", "<summary>", "<dialog>", "<template>", "<slot>", "<picture>"],
    syntaxElements: ["doctype", "charset", "viewport", "lang attribute", "alt attribute", "href", "src", "id", "class", "data attributes"],
    templates: [
      (d) => ({
        question: `Which HTML element is used to ${d.actions[Math.floor(Math.random() * d.actions.length)]} ${d.scenarios[Math.floor(Math.random() * d.scenarios.length)]}?`,
        correct: d.keywords[Math.floor(Math.random() * d.keywords.length)],
        wrong: d.keywords.filter((_, i) => i !== Math.floor(Math.random() * d.keywords.length)).slice(0, 3)
      }),
      (d) => ({
        question: `What is the purpose of the ${d.keywords[Math.floor(Math.random() * d.keywords.length)]} element in HTML5?`,
        correct: `To ${d.actions[Math.floor(Math.random() * d.actions.length)]} content semantically`,
        wrong: [`To style the page`, `To add JavaScript`, `To create animations`]
      }),
      (d) => ({
        question: `Which attribute is essential for ${d.concepts[Math.floor(Math.random() * d.concepts.length)]}?`,
        correct: d.syntaxElements[Math.floor(Math.random() * d.syntaxElements.length)],
        wrong: d.syntaxElements.filter((_, i) => i !== 0).slice(0, 3)
      }),
    ]
  },
  css: {
    concepts: ["flexbox", "grid layout", "responsive design", "animations", "transitions", "transforms", "pseudo-classes", "pseudo-elements", "specificity", "box model"],
    actions: ["center", "align", "distribute", "animate", "transform", "style", "position", "layer", "hide", "reveal"],
    scenarios: ["a flex container", "a grid layout", "a responsive image", "a hover effect", "a loading spinner", "a card component", "a navigation bar", "a modal overlay", "a tooltip", "a dropdown"],
    keywords: ["display", "position", "flex", "grid", "transform", "transition", "animation", "z-index", "overflow", "opacity", "visibility", "float", "clear", "margin", "padding"],
    syntaxElements: ["::before", "::after", ":hover", ":focus", ":active", ":nth-child()", ":first-child", ":last-child", ":not()", ":is()", "@media", "@keyframes", "@supports", "var()", "calc()"],
    templates: [
      (d) => ({
        question: `Which CSS property is used to ${d.actions[Math.floor(Math.random() * d.actions.length)]} elements in ${d.scenarios[Math.floor(Math.random() * d.scenarios.length)]}?`,
        correct: d.keywords[Math.floor(Math.random() * d.keywords.length)],
        wrong: d.keywords.filter((_, i) => i !== 0).slice(0, 3)
      }),
      (d) => ({
        question: `What does ${d.syntaxElements[Math.floor(Math.random() * d.syntaxElements.length)]} do in CSS?`,
        correct: `Applies styles for ${d.concepts[Math.floor(Math.random() * d.concepts.length)]}`,
        wrong: [`Changes font size`, `Removes elements`, `Adds JavaScript`]
      }),
      (d) => ({
        question: `In ${d.concepts[Math.floor(Math.random() * d.concepts.length)]}, which property controls the main axis?`,
        correct: d.keywords[Math.floor(Math.random() * 5)],
        wrong: d.keywords.slice(5, 8)
      }),
    ]
  },
  javascript: {
    concepts: ["closures", "promises", "async/await", "event delegation", "prototypal inheritance", "hoisting", "scope", "callbacks", "higher-order functions", "destructuring"],
    actions: ["execute", "return", "iterate", "filter", "map", "reduce", "fetch", "parse", "stringify", "validate"],
    scenarios: ["an API call", "array manipulation", "event handling", "form validation", "data transformation", "error handling", "state management", "DOM manipulation", "timer functions", "module imports"],
    keywords: ["const", "let", "var", "function", "arrow function", "async", "await", "Promise", "then", "catch", "try", "throw", "new", "this", "class"],
    syntaxElements: ["spread operator (...)", "rest parameters", "template literals", "optional chaining (?.) ", "nullish coalescing (??)", "destructuring assignment", "default parameters", "computed properties", "shorthand methods", "import/export"],
    templates: [
      (d) => ({
        question: `What is the output when using ${d.concepts[Math.floor(Math.random() * d.concepts.length)]} in JavaScript?`,
        correct: `It helps ${d.actions[Math.floor(Math.random() * d.actions.length)]} data efficiently`,
        wrong: [`It causes an error`, `It returns undefined always`, `It blocks the main thread`]
      }),
      (d) => ({
        question: `Which keyword is used to ${d.actions[Math.floor(Math.random() * d.actions.length)]} in ${d.scenarios[Math.floor(Math.random() * d.scenarios.length)]}?`,
        correct: d.keywords[Math.floor(Math.random() * d.keywords.length)],
        wrong: d.keywords.filter((_, i) => i !== 0).slice(0, 3)
      }),
      (d) => ({
        question: `What does ${d.syntaxElements[Math.floor(Math.random() * d.syntaxElements.length)]} allow you to do?`,
        correct: `${d.actions[Math.floor(Math.random() * d.actions.length)].charAt(0).toUpperCase() + d.actions[Math.floor(Math.random() * d.actions.length)].slice(1)} values more easily`,
        wrong: [`Create CSS styles`, `Define HTML elements`, `Remove event listeners`]
      }),
    ]
  },
  java: {
    concepts: ["inheritance", "polymorphism", "encapsulation", "abstraction", "interfaces", "generics", "collections", "streams", "lambdas", "exceptions"],
    actions: ["implement", "extend", "override", "instantiate", "serialize", "deserialize", "iterate", "filter", "collect", "throw"],
    scenarios: ["a class hierarchy", "interface implementation", "exception handling", "stream processing", "generic types", "collection manipulation", "thread management", "file I/O", "network requests", "database operations"],
    keywords: ["public", "private", "protected", "static", "final", "abstract", "interface", "extends", "implements", "super", "this", "new", "void", "return", "throw"],
    syntaxElements: ["@Override", "@FunctionalInterface", "@Deprecated", "try-catch-finally", "synchronized", "volatile", "transient", "instanceof", "switch expression", "record class"],
    templates: [
      (d) => ({
        question: `In Java, which keyword is used for ${d.concepts[Math.floor(Math.random() * d.concepts.length)]}?`,
        correct: d.keywords[Math.floor(Math.random() * d.keywords.length)],
        wrong: d.keywords.filter((_, i) => i !== 0).slice(0, 3)
      }),
      (d) => ({
        question: `What happens when you ${d.actions[Math.floor(Math.random() * d.actions.length)]} in ${d.scenarios[Math.floor(Math.random() * d.scenarios.length)]}?`,
        correct: `The ${d.concepts[Math.floor(Math.random() * d.concepts.length)]} principle is applied`,
        wrong: [`A compilation error occurs`, `The program crashes`, `Nothing happens`]
      }),
      (d) => ({
        question: `Which annotation is commonly used for ${d.actions[Math.floor(Math.random() * d.actions.length)]} methods in Java?`,
        correct: d.syntaxElements[Math.floor(Math.random() * 3)],
        wrong: d.syntaxElements.slice(3, 6)
      }),
    ]
  },
  python: {
    concepts: ["list comprehensions", "decorators", "generators", "context managers", "duck typing", "multiple inheritance", "metaclasses", "descriptors", "async programming", "type hints"],
    actions: ["iterate", "filter", "map", "yield", "decorate", "inherit", "serialize", "parse", "validate", "transform"],
    scenarios: ["data processing", "file handling", "API requests", "database queries", "web scraping", "machine learning", "automation scripts", "testing", "configuration", "logging"],
    keywords: ["def", "class", "lambda", "yield", "async", "await", "with", "as", "import", "from", "try", "except", "finally", "raise", "pass"],
    syntaxElements: ["f-strings", "*args", "**kwargs", "walrus operator (:=)", "list slicing", "dictionary comprehension", "set operations", "unpacking", "global/nonlocal", "match-case"],
    templates: [
      (d) => ({
        question: `In Python, what is ${d.concepts[Math.floor(Math.random() * d.concepts.length)]} used for?`,
        correct: `To ${d.actions[Math.floor(Math.random() * d.actions.length)]} data efficiently`,
        wrong: [`To define classes only`, `To handle errors only`, `To import modules only`]
      }),
      (d) => ({
        question: `Which Python keyword enables ${d.scenarios[Math.floor(Math.random() * d.scenarios.length)]}?`,
        correct: d.keywords[Math.floor(Math.random() * d.keywords.length)],
        wrong: d.keywords.filter((_, i) => i !== 0).slice(0, 3)
      }),
      (d) => ({
        question: `What does ${d.syntaxElements[Math.floor(Math.random() * d.syntaxElements.length)]} allow in Python?`,
        correct: `${d.actions[Math.floor(Math.random() * d.actions.length)].charAt(0).toUpperCase() + d.actions[Math.floor(Math.random() * d.actions.length)].slice(1)} with cleaner syntax`,
        wrong: [`Only string formatting`, `Only error handling`, `Only class definitions`]
      }),
    ]
  }
};

// Additional static question pools for more variety
const staticQuestionPools: Record<Category, { question: string; correct: string; wrong: string[] }[]> = {
  html: [
    { question: "What does HTML stand for?", correct: "HyperText Markup Language", wrong: ["High Tech Modern Language", "Home Tool Markup Language", "Hyperlink Text Management Language"] },
    { question: "Which tag is used for the largest heading?", correct: "<h1>", wrong: ["<heading>", "<h6>", "<head>"] },
    { question: "What is the correct HTML element for inserting a line break?", correct: "<br>", wrong: ["<break>", "<lb>", "<newline>"] },
    { question: "Which HTML attribute specifies an alternate text for an image?", correct: "alt", wrong: ["title", "src", "longdesc"] },
    { question: "Which element is used to define important text?", correct: "<strong>", wrong: ["<b>", "<important>", "<i>"] },
    { question: "What is the correct HTML for creating a hyperlink?", correct: "<a href='url'>", wrong: ["<link href='url'>", "<a url='url'>", "<hyperlink='url'>"] },
    { question: "Which HTML element defines the title of a document?", correct: "<title>", wrong: ["<head>", "<meta>", "<header>"] },
    { question: "Which input type is used for email addresses?", correct: "email", wrong: ["mail", "text", "address"] },
    { question: "What is the purpose of the <meta> tag?", correct: "To provide metadata about the document", wrong: ["To create a menu", "To add styling", "To define scripts"] },
    { question: "Which element is used for ordered lists?", correct: "<ol>", wrong: ["<ul>", "<li>", "<list>"] },
  ],
  css: [
    { question: "What does CSS stand for?", correct: "Cascading Style Sheets", wrong: ["Creative Style Sheets", "Computer Style Sheets", "Colorful Style Sheets"] },
    { question: "Which property is used to change the background color?", correct: "background-color", wrong: ["color", "bgcolor", "background"] },
    { question: "How do you select an element with id 'demo'?", correct: "#demo", wrong: [".demo", "demo", "*demo"] },
    { question: "Which property controls the text size?", correct: "font-size", wrong: ["text-size", "font-style", "text-style"] },
    { question: "How do you make text bold?", correct: "font-weight: bold", wrong: ["text-style: bold", "font: bold", "style: bold"] },
    { question: "Which property is used for spacing inside an element?", correct: "padding", wrong: ["margin", "spacing", "border"] },
    { question: "What is the default position value?", correct: "static", wrong: ["relative", "absolute", "fixed"] },
    { question: "Which value hides an element but keeps its space?", correct: "visibility: hidden", wrong: ["display: none", "opacity: 0", "hidden: true"] },
    { question: "How do you center a block element horizontally?", correct: "margin: 0 auto", wrong: ["text-align: center", "align: center", "center: true"] },
    { question: "Which property creates rounded corners?", correct: "border-radius", wrong: ["corner-radius", "border-curve", "round-corner"] },
  ],
  javascript: [
    { question: "Which company developed JavaScript?", correct: "Netscape", wrong: ["Microsoft", "Google", "Apple"] },
    { question: "How do you declare a constant in JavaScript?", correct: "const", wrong: ["var", "let", "constant"] },
    { question: "Which method converts JSON to a JavaScript object?", correct: "JSON.parse()", wrong: ["JSON.stringify()", "JSON.convert()", "JSON.toObject()"] },
    { question: "What is the result of typeof null?", correct: "object", wrong: ["null", "undefined", "boolean"] },
    { question: "Which array method adds elements to the end?", correct: "push()", wrong: ["pop()", "shift()", "unshift()"] },
    { question: "How do you write a comment in JavaScript?", correct: "// comment", wrong: ["/* comment", "# comment", "<!-- comment -->"] },
    { question: "Which operator is used for strict equality?", correct: "===", wrong: ["==", "=", "!=="] },
    { question: "What does NaN stand for?", correct: "Not a Number", wrong: ["No actual Number", "Null and None", "Number and Null"] },
    { question: "Which method removes the last element from an array?", correct: "pop()", wrong: ["push()", "shift()", "slice()"] },
    { question: "How do you create a function in JavaScript?", correct: "function name()", wrong: ["def name()", "create name()", "func name()"] },
  ],
  java: [
    { question: "Which company originally developed Java?", correct: "Sun Microsystems", wrong: ["Microsoft", "Oracle", "Google"] },
    { question: "What is the entry point of a Java program?", correct: "main method", wrong: ["init method", "start method", "run method"] },
    { question: "Which keyword is used to inherit a class?", correct: "extends", wrong: ["implements", "inherits", "super"] },
    { question: "What is the size of int in Java?", correct: "32 bits", wrong: ["16 bits", "64 bits", "8 bits"] },
    { question: "Which collection allows duplicate elements?", correct: "ArrayList", wrong: ["HashSet", "TreeSet", "LinkedHashSet"] },
    { question: "What does JVM stand for?", correct: "Java Virtual Machine", wrong: ["Java Visual Machine", "Java Variable Machine", "Java Verified Machine"] },
    { question: "Which keyword prevents inheritance?", correct: "final", wrong: ["static", "private", "sealed"] },
    { question: "What is the default value of a boolean?", correct: "false", wrong: ["true", "null", "0"] },
    { question: "Which interface must be implemented for sorting?", correct: "Comparable", wrong: ["Sortable", "Ordered", "Comparator"] },
    { question: "How do you handle exceptions in Java?", correct: "try-catch block", wrong: ["if-else block", "handle block", "error block"] },
  ],
  python: [
    { question: "Who created Python?", correct: "Guido van Rossum", wrong: ["James Gosling", "Brendan Eich", "Dennis Ritchie"] },
    { question: "Which keyword is used to define a function?", correct: "def", wrong: ["function", "func", "define"] },
    { question: "What is the output of print(2**3)?", correct: "8", wrong: ["6", "9", "5"] },
    { question: "Which data type is immutable?", correct: "tuple", wrong: ["list", "dictionary", "set"] },
    { question: "How do you start a comment in Python?", correct: "#", wrong: ["//", "/*", "<!--"] },
    { question: "Which method adds an element to a list?", correct: "append()", wrong: ["add()", "insert()", "push()"] },
    { question: "What does PEP stand for?", correct: "Python Enhancement Proposal", wrong: ["Python Execution Protocol", "Python Environment Package", "Python Extension Program"] },
    { question: "Which keyword is used for exception handling?", correct: "try", wrong: ["catch", "handle", "error"] },
    { question: "What is the result of bool('')?", correct: "False", wrong: ["True", "None", "Error"] },
    { question: "Which function returns the length of a list?", correct: "len()", wrong: ["length()", "size()", "count()"] },
  ]
};

// Fisher-Yates shuffle
function shuffle<T>(array: T[]): T[] {
  const shuffled = [...array];
  for (let i = shuffled.length - 1; i > 0; i--) {
    const j = Math.floor(Math.random() * (i + 1));
    [shuffled[i], shuffled[j]] = [shuffled[j], shuffled[i]];
  }
  return shuffled;
}

// Generate a unique question ID
function generateId(): string {
  return Math.random().toString(36).substring(2, 15) + Date.now().toString(36);
}

// Generate questions for a category
export function generateQuestions(category: Category, count: number = 25): Question[] {
  const questions: Question[] = [];
  const usedQuestions = new Set<string>();
  const categoryData = questionData[category];
  const staticPool = [...staticQuestionPools[category]];

  // Shuffle static pool
  const shuffledStatic = shuffle(staticPool);

  // Mix of static and dynamic questions
  let staticIndex = 0;
  let attempts = 0;
  const maxAttempts = count * 10;

  while (questions.length < count && attempts < maxAttempts) {
    attempts++;
    
    let questionObj: { question: string; correct: string; wrong: string[] };

    // Alternate between static and dynamic, favoring dynamic for variety
    if (staticIndex < shuffledStatic.length && Math.random() < 0.4) {
      questionObj = shuffledStatic[staticIndex];
      staticIndex++;
    } else {
      // Generate dynamic question
      const template = categoryData.templates[Math.floor(Math.random() * categoryData.templates.length)];
      questionObj = template(categoryData);
    }

    // Check for uniqueness
    const questionKey = questionObj.question.toLowerCase();
    if (usedQuestions.has(questionKey)) {
      continue;
    }
    usedQuestions.add(questionKey);

    // Prepare options
    const allOptions = [questionObj.correct, ...questionObj.wrong.slice(0, 3)];
    const shuffledOptions = shuffle(allOptions);
    const correctIndex = shuffledOptions.indexOf(questionObj.correct);

    questions.push({
      id: generateId(),
      question: questionObj.question,
      options: shuffledOptions,
      correctIndex,
      category
    });
  }

  // If we still need more questions, generate additional dynamic ones
  while (questions.length < count) {
    const template = categoryData.templates[Math.floor(Math.random() * categoryData.templates.length)];
    const questionObj = template(categoryData);
    
    const allOptions = [questionObj.correct, ...questionObj.wrong.slice(0, 3)];
    const shuffledOptions = shuffle(allOptions);
    const correctIndex = shuffledOptions.indexOf(questionObj.correct);

    questions.push({
      id: generateId(),
      question: questionObj.question + ` (#${questions.length + 1})`,
      options: shuffledOptions,
      correctIndex,
      category
    });
  }

  return shuffle(questions);
}

export const categories: { id: Category; name: string; icon: string; color: string }[] = [
  { id: "html", name: "HTML", icon: "🌐", color: "from-orange-500 to-red-500" },
  { id: "css", name: "CSS", icon: "🎨", color: "from-blue-500 to-cyan-500" },
  { id: "javascript", name: "JavaScript", icon: "⚡", color: "from-yellow-500 to-amber-500" },
  { id: "java", name: "Java", icon: "☕", color: "from-red-600 to-orange-600" },
  { id: "python", name: "Python", icon: "🐍", color: "from-green-500 to-emerald-500" },
];
