import { createContext, useContext, useState, useEffect, ReactNode } from "react";

export interface User {
  email: string;
  name: string;
  createdAt: string;
}

export interface UserStats {
  totalQuizzes: number;
  highestScore: number;
  lastScore: number;
  totalQuestions: number;
  correctAnswers: number;
}

interface AuthContextType {
  user: User | null;
  stats: UserStats;
  isAuthenticated: boolean;
  login: (email: string, password: string) => { success: boolean; error?: string };
  signup: (name: string, email: string, password: string) => { success: boolean; error?: string };
  logout: () => void;
  updateStats: (quizScore: number, totalQuestions: number, correctAnswers: number) => void;
}

const AuthContext = createContext<AuthContextType | null>(null);

const DEFAULT_STATS: UserStats = {
  totalQuizzes: 0,
  highestScore: 0,
  lastScore: 0,
  totalQuestions: 0,
  correctAnswers: 0,
};

export function AuthProvider({ children }: { children: ReactNode }) {
  const [user, setUser] = useState<User | null>(null);

  // Load user session on mount
  useEffect(() => {
    const session = localStorage.getItem("dani_ai_session");
    if (session) {
      try {
        setUser(JSON.parse(session));
      } catch {
        localStorage.removeItem("dani_ai_session");
      }
    }
  }, []);

  const getUsers = (): Record<string, { name: string; password: string; createdAt: string }> => {
    try {
      return JSON.parse(localStorage.getItem("dani_ai_users") || "{}");
    } catch {
      return {};
    }
  };

  const getStats = (): UserStats => {
    if (!user) return DEFAULT_STATS;
    try {
      const allStats = JSON.parse(localStorage.getItem("dani_ai_stats") || "{}");
      return allStats[user.email] || DEFAULT_STATS;
    } catch {
      return DEFAULT_STATS;
    }
  };

  const signup = (name: string, email: string, password: string) => {
    const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    if (!emailRegex.test(email)) {
      return { success: false, error: "Invalid email format" };
    }

    const users = getUsers();
    if (users[email]) {
      return { success: false, error: "Email already registered" };
    }

    if (password.length < 6) {
      return { success: false, error: "Password must be at least 6 characters" };
    }

    const newUser = { name, password, createdAt: new Date().toISOString() };
    users[email] = newUser;
    localStorage.setItem("dani_ai_users", JSON.stringify(users));

    // Initialize stats for new user
    const allStats = JSON.parse(localStorage.getItem("dani_ai_stats") || "{}");
    allStats[email] = DEFAULT_STATS;
    localStorage.setItem("dani_ai_stats", JSON.stringify(allStats));

    const userSession = { email, name, createdAt: newUser.createdAt };
    setUser(userSession);
    localStorage.setItem("dani_ai_session", JSON.stringify(userSession));

    return { success: true };
  };

  const login = (email: string, password: string) => {
    const users = getUsers();
    const userData = users[email];

    if (!userData) {
      return { success: false, error: "Email not registered" };
    }

    if (userData.password !== password) {
      return { success: false, error: "Incorrect password" };
    }

    const userSession = { email, name: userData.name, createdAt: userData.createdAt };
    setUser(userSession);
    localStorage.setItem("dani_ai_session", JSON.stringify(userSession));

    return { success: true };
  };

  const logout = () => {
    setUser(null);
    localStorage.removeItem("dani_ai_session");
  };

  const updateStats = (quizScore: number, totalQuestions: number, correctAnswers: number) => {
    if (!user) return;

    const allStats = JSON.parse(localStorage.getItem("dani_ai_stats") || "{}");
    const currentStats = allStats[user.email] || DEFAULT_STATS;

    const newStats: UserStats = {
      totalQuizzes: currentStats.totalQuizzes + 1,
      highestScore: Math.max(currentStats.highestScore, quizScore),
      lastScore: quizScore,
      totalQuestions: currentStats.totalQuestions + totalQuestions,
      correctAnswers: currentStats.correctAnswers + correctAnswers,
    };

    allStats[user.email] = newStats;
    localStorage.setItem("dani_ai_stats", JSON.stringify(allStats));
  };

  const stats = getStats();

  return (
    <AuthContext.Provider
      value={{
        user,
        stats,
        isAuthenticated: !!user,
        login,
        signup,
        logout,
        updateStats,
      }}
    >
      {children}
    </AuthContext.Provider>
  );
}

export function useAuth() {
  const context = useContext(AuthContext);
  if (!context) {
    throw new Error("useAuth must be used within an AuthProvider");
  }
  return context;
}
